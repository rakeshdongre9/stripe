<?php


  define('STRIPE_PUBLISH_KEY','pk_test_OEjAw7I6wuwrt85m0LXciQJs');


  $card_number = "4242424242424242";
  
  $expiry_year = "2040";
  $expiry_month =  "12";
  $cvc_code =  "123";
  
  $ch = curl_init();

  curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/tokens');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, "card[number]=$card_number&card[exp_month]=$expiry_month&card[exp_year]=$expiry_year&card[cvc]=$cvc_code");
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_USERPWD, STRIPE_PUBLISH_KEY . ':' . '');
  

  $headers = array();
  $headers[] = 'Content-Type: application/x-www-form-urlencoded';
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

  $result = curl_exec($ch);
  
  
  if (curl_errno($ch)) {
      $this->session->set_flashdata('msg','invalid card details');
     
      echo 'Error:' . curl_error($ch);
     $json = ['result'=>'unsuccessfull','status'=>0,'message'=>'unsuccessfull'];
     }else{
     $result = json_decode($result);
     $json = ['result'=>$result->id,'status'=>1,'message'=>'successfull'];
  
    
  }
  curl_close ($ch);

    header('Content-type:application/json');
    echo json_encode($json);
