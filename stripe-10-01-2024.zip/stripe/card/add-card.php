<?php


// Get the token from the POST data
$token = "tok_1OWfnmJuhgRuRnD558W1j4XG"; // Replace with the actual token

// Set your Stripe secret key and customer ID
$stripeSecretKey = "sk_test_51C4xU2JuhgRuRnD5oQSLVYlwIKKxq0JDXVzplGhZdUzR8kpoAuULyHhgbJ8KMcxsxzdBiZJ0tc6aaMac0BxBfLzn009YOLiMCU";
$customerID = 'cus_PLGeK3srBCcCs1'; // Replace with the actual customer ID

$ch = curl_init('https://api.stripe.com/v1/payment_methods');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'type' => 'card',
    'card[token]' => $token,
]));

$headers = [
    'Content-Type: application/x-www-form-urlencoded',
    'Authorization: Bearer '.$stripeSecretKey,
];

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo json_encode(['success' => false, 'error' => curl_error($ch)]);
} else {
    $paymentMethod = json_decode($response);

    // Attach the PaymentMethod to the customer
    $ch = curl_init("https://api.stripe.com/v1/payment_methods/{$paymentMethod->id}/attach");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['customer' => $customerID]));

    $headers = [
        'Content-Type: application/x-www-form-urlencoded',
        'Authorization: Bearer '.$stripeSecretKey,
    ];

    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $attachResponse = curl_exec($ch);

    if (curl_errno($ch)) {
        echo json_encode(['success' => false, 'error' => curl_error($ch)]);
    } else {
        // Retrieve customer's payment methods
        $ch = curl_init("https://api.stripe.com/v1/customers/{$customerID}");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer '.$stripeSecretKey]);
        $customerInfo = json_decode(curl_exec($ch));
        curl_close($ch);

        // Choose the payment method you want to set as default
        $defaultPaymentMethodId = $paymentMethod->id;

        // Update customer with new default payment method
        $ch = curl_init("https://api.stripe.com/v1/customers/{$customerID}");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['invoice_settings[default_payment_method]' => $defaultPaymentMethodId]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer '.$stripeSecretKey]);
        $updateCustomerResponse = json_decode(curl_exec($ch));
        curl_close($ch);

        echo json_encode(['success' => true, 'payment_method_id' => $paymentMethod->id]);
    }

    curl_close($ch);
}
?>
