<?php

$secretKey = 'sk_test_51C4xU2JuhgRuRnD5oQSLVYlwIKKxq0JDXVzplGhZdUzR8kpoAuULyHhgbJ8KMcxsxzdBiZJ0tc6aaMac0BxBfLzn009YOLiMCU';
$apiUrl = 'https://api.stripe.com/v1/customers';

// Customer information
$customerData = [
    'email' => 'customer@example.com',
    'description' => 'Customer Description', // Optional
];

// Convert the array to a query string
$customerQueryString = http_build_query($customerData);

// Initialize cURL session
$ch = curl_init($apiUrl);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $customerQueryString);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $secretKey,
]);

// Execute cURL session
$response = curl_exec($ch);

// Close cURL session
curl_close($ch);

// Decode the JSON response
$customer = json_decode($response, true);

// Handle the $customer object as needed
var_dump($customer);

?>