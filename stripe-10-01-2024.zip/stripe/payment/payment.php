<?php
 

          $token = "tok_1OWubaJuhgRuRnD5mK4bRHKJ";
          
          define('STRIPE_KEY','sk_test_51C4xU2JuhgRuRnD5oQSLVYlwIKKxq0JDXVzplGhZdUzR8kpoAuULyHhgbJ8KMcxsxzdBiZJ0tc6aaMac0BxBfLzn009YOLiMCU');

      
	$url = 'https://api.stripe.com/v1/charges';
	
        $fields = [
            'amount' => (10*100),
            'currency' => "USD",
            'source' => $token,
            //'metadata' => ['shipping_id'=>1]
        ];

        $fields_string = http_build_query($fields);

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, "https://api.stripe.com/v1/charges");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_USERPWD, STRIPE_KEY . ':' . '');

       $headers = array();
       $headers[] = "Content-Type: application/x-www-form-urlencoded";
       curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

       $response = curl_exec($ch);  
       $response = json_decode($response);
       
    
       $stripe_transaction_status = $response->status; 
     
        $stripe_transaction_id = $response->id; 

    

    if (isset($response->error)) {
        
        $error_code = $response->error->code;
        $error_message = $response->error->message;
        $error_type = $response->error->type;

        if ($error_type === 'card_error') {
            if ($error_code === 'incorrect_number') {
                $message = 'Invalid card number.';
            } elseif ($error_code === 'invalid_expiry_month' || $error_code === 'invalid_expiry_year') {
                $message = 'Invalid expiration date.';
            } elseif ($error_code === 'invalid_cvc') {
                $message = 'Invalid CVC code.';
            } else {
                $message = 'Card validation error: ' . $error_message;
            }
        } elseif ($error_type === 'invalid_request_error' && $error_code === 'incorrect_currency') {
            $message = 'Invalid currency provided.';
        } else {
            $message = 'Payment error: ' . $error_message;
        }
              
              
              echo $message;
     
    }
    else
    {
        
              echo "success";

        
    }


    
    ?>